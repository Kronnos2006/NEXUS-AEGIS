# NEXUS AEGIS v5.0 — Sistema de Inteligencia Atribucional

## Arquitectura General

```
┌─────────────────────────────────────────────────────────────────┐
│                   NEXUS AEGIS v5.0 Core                         │
│                                                                  │
│  ┌──────────────┐   ┌─────────────────┐   ┌──────────────────┐ │
│  │   Valeria    │   │  Attributional  │   │  Infinite Canvas │ │
│  │ (Cerebro)    │◄──│  Intelligence   │──►│  (Infinite-Mon   │ │
│  │ Gemma4+Nemo  │   │    Engine       │   │   Inspired)      │ │
│  └──────┬───────┘   └─────────────────┘   └──────────────────┘ │
│         │                                                        │
│  ┌──────▼───────────────────────────────────────────────────┐   │
│  │              IntelligentRouter v3.8 Alpha                │   │
│  └──────┬───────────┬────────────┬──────────────────────────┘   │
│         │           │            │                               │
│  ┌──────▼──┐  ┌─────▼──┐  ┌─────▼──────────────────────────┐   │
│  │ MCP     │  │  n8n   │  │        Sub-Agents               │   │
│  │ Layer   │  │ Engine │  │ AegisShield · CodeGuard · NMS   │   │
│  └──────┬──┘  └─────┬──┘  └─────────────────────────────────┘   │
└─────────│───────────│──────────────────────────────────────────┘
          │           │
┌─────────▼──────┐  ┌─▼──────────────────────────────────────────┐
│  MCP Servers   │  │     n8n Automation Workflows                │
│                │  │  (enescingoz/awesome-n8n-templates)         │
│ ☁️ gcloud-mcp  │  │                                             │
│ 🛡️ security   │  │ • AI Email Labeling (Gmail+OpenAI)          │
│ 🗄️ db-toolbox │  │ • Telegram→NEXUS Bridge (LangChain)         │
│ 🐙 github-mcp  │  │ • Security Alert Pipeline (AEGIS→Slack)    │
│ 📧 workspace  │  │ • RAG Knowledge Sync (Qdrant)               │
│               │  │ • Agent Metrics (→Google Sheets)            │
│ google/mcp    │  │ • Code Vulnerability Scanner (GitHub PR)    │
│ google/mcp-   │  │ • WhatsApp Business Bot (OpenAI RAG)        │
│ security      │  │ • Financial Data Aggregator (Crypto+NMS)    │
│ googleapis/   │  │                                             │
│ gcloud-mcp    │  └────────────────────────────────────────────┘
│ googleapis/   │
│ mcp-toolbox   │
└───────────────┘
```

## Nuevas Funcionalidades v5.0

### 1. Motor de Inteligencia Atribucional
- **Attribution Score** por agente: tasa de éxito + confianza promedio + latencia
- **Cadena de atribución criptográfica**: cada decisión trazada en 4 pasos (Router → Agent → Memory → AEGIS)
- **Firma Ed25519** en cada acción aprobada
- **Hash SHA-256 encadenado** en toda la memoria persistente

### 2. Canvas Infinito (inspirado en homanp/infinite-monitor)
- Pan + Zoom con rueda del ratón (Ctrl+scroll = zoom, scroll normal = pan)
- Widgets arrastrables con resize handle
- Tipos: System Health, Attribution Map, MCP Status, Security Feed, Agent Network, Chat
- Grid snapping visual con puntos de referencia
- Modal para añadir widgets dinámicamente

### 3. Capa MCP Completa (google/mcp ecosystem)
- **Google Cloud MCP** (`@google-cloud/gcloud-mcp`): gcloud NL, logs, metrics
- **Google Security MCP** (`uvx secops_mcp`): Chronicle, SCC, GTI
- **MCP Toolbox for Databases** (`googleapis/mcp-toolbox`): NL2SQL, semantic search
- **GitHub MCP** (`github/github-mcp-server`): repos, issues, CI/CD
- **Google Workspace MCP** (`taylorwilsdon/google_workspace_mcp`): Gmail, Calendar, Drive
- Toggle individual de tools por servidor
- Integration con sistema atribucional (cada tool call registrado)

### 4. Motor de Automatización n8n (enescingoz/awesome-n8n-templates)
8 workflows pre-configurados categorizados por dominio:
- **Email**: AI Gmail labeling, phishing detection, cold email automation
- **Messaging**: Telegram+LangChain bot, WhatsApp RAG chatbot
- **DevOps**: Security pipeline, agent metrics to Sheets, code scanner
- **AI/RAG**: Knowledge sync a Qdrant, daily briefings
- **Finance**: Crypto aggregator + NMS economy analysis

## Configuración

### Variables de Entorno
```env
# Core
TELEGRAM_BOT_TOKEN=
NVIDIA_API_KEY=
TELEGRAM_CHAT_ID=

# MCP Servers
GOOGLE_CLOUD_PROJECT=
GOOGLE_APPLICATION_CREDENTIALS=
GITHUB_PERSONAL_ACCESS_TOKEN=
GOOGLE_OAUTH_CLIENT_ID=
GOOGLE_OAUTH_CLIENT_SECRET=

# n8n
N8N_BASIC_AUTH_USER=admin
N8N_BASIC_AUTH_PASSWORD=admin

# Ollama / Gemma 4
OLLAMA_BASE_URL=http://localhost:11434
PRIMARY_LLM=gemma4:e2b
FALLBACK_LLM=nemotron
```

### Instalar MCP Servers
```bash
# Google Cloud MCP
npx -y @google-cloud/gcloud-mcp

# Google Security MCP (Chronicle + GTI + SCC + SOAR)
pip install google-secops-mcp gti-mcp scc-mcp
uvx --from google-secops-mcp secops_mcp

# MCP Toolbox for Databases
# See: https://github.com/googleapis/mcp-toolbox
# Configure tools.yaml with your DB connection

# GitHub MCP
docker run -i --rm \
  -e GITHUB_PERSONAL_ACCESS_TOKEN=<token> \
  ghcr.io/github/github-mcp-server

# Google Workspace MCP
uvx workspace-mcp --tool-tier complete
```

### Importar Workflows n8n
Los 8 workflows están en `/src/n8n/workflows/`. Para importarlos:
1. Abrir n8n en http://localhost:5678
2. Settings → Import Workflow
3. Seleccionar cada `.json` del directorio `/workflows`

## Estructura del Proyecto

```
nexus-aegis-v5/
├── src/
│   ├── App.tsx                    # Dashboard principal (este archivo)
│   ├── nexus/
│   │   ├── core.ts                # Valeria + Router + Orchestrator
│   │   ├── agents.ts              # Sub-agentes con Attribution Score
│   │   ├── attribution/
│   │   │   ├── engine.ts          # Motor de atribución
│   │   │   ├── chain.ts           # Cadena criptográfica
│   │   │   └── scorer.ts          # Cálculo de confianza
│   │   ├── mcp/
│   │   │   ├── client.ts          # Cliente MCP unificado
│   │   │   ├── gcloud.ts          # Google Cloud MCP bridge
│   │   │   ├── security.ts        # Security MCP bridge
│   │   │   └── registry.ts        # Registro de servidores
│   │   ├── n8n/
│   │   │   ├── bridge.ts          # Webhook bridge n8n↔NEXUS
│   │   │   └── workflows/         # JSON templates
│   │   ├── ai/
│   │   │   ├── provider.ts        # Gemma4 + Nemotron
│   │   │   └── prompts.ts
│   │   ├── memory/
│   │   │   ├── memory.ts
│   │   │   └── memory.service.ts
│   │   ├── database.ts
│   │   ├── aegis.ts
│   │   ├── watchdog.ts
│   │   └── skills.ts
│   └── components/
│       ├── Canvas/                 # Infinite canvas widgets
│       ├── Attribution/            # Atributional intelligence UI
│       ├── MCP/                    # MCP server management
│       └── N8N/                    # Workflow management
├── server.ts                       # Express + Socket.IO server
├── docker-compose.yml              # Nexus + Ollama + Redis + n8n
└── .env.example
```
