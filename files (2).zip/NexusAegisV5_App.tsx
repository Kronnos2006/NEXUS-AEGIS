import React, { useState, useCallback, useRef, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";

// ─── Types ───────────────────────────────────────────────────────────────────

interface Widget {
  id: string;
  type: WidgetType;
  title: string;
  x: number;
  y: number;
  w: number;
  h: number;
  data?: any;
  status: "idle" | "loading" | "active" | "error";
  agentId?: string;
  attribution?: AttributionData;
}

interface AttributionData {
  source: string;
  confidence: number;
  reasoning: string;
  mcpServer?: string;
  n8nWorkflow?: string;
  timestamp: string;
  chain: AttributionChain[];
}

interface AttributionChain {
  step: number;
  actor: string;
  action: string;
  output: string;
  confidence: number;
}

interface MCPServer {
  id: string;
  name: string;
  url: string;
  status: "connected" | "disconnected" | "error";
  tools: MCPTool[];
  category: "security" | "database" | "cloud" | "search" | "comms";
  icon: string;
}

interface MCPTool {
  name: string;
  description: string;
  active: boolean;
}

interface N8NWorkflow {
  id: string;
  name: string;
  category: string;
  trigger: string;
  status: "active" | "paused" | "error";
  lastRun?: string;
  executions: number;
  description: string;
}

interface Agent {
  id: string;
  name: string;
  role: string;
  status: "active" | "idle" | "working";
  attribution_score: number;
  tasks_completed: number;
  avg_confidence: number;
}

type WidgetType =
  | "system_health"
  | "attribution_map"
  | "mcp_status"
  | "n8n_workflows"
  | "agent_network"
  | "security_feed"
  | "chat"
  | "memory_graph"
  | "custom";

type ActivePanel = "canvas" | "attribution" | "mcp" | "n8n" | "agents";

// ─── Mock Data ────────────────────────────────────────────────────────────────

const INITIAL_MCP_SERVERS: MCPServer[] = [
  {
    id: "gcloud",
    name: "Google Cloud MCP",
    url: "npx @google-cloud/gcloud-mcp",
    status: "connected",
    category: "cloud",
    icon: "☁️",
    tools: [
      { name: "execute_gcloud", description: "Run gcloud commands via NL", active: true },
      { name: "list_logs", description: "Query Cloud Logging", active: true },
      { name: "list_metrics", description: "Get Cloud Monitoring metrics", active: false },
    ],
  },
  {
    id: "security",
    name: "Google Security MCP",
    url: "uvx secops_mcp",
    status: "connected",
    category: "security",
    icon: "🛡️",
    tools: [
      { name: "chronicle_search", description: "Threat detection & hunting", active: true },
      { name: "scc_findings", description: "Security Command Center", active: true },
      { name: "gti_lookup", description: "Google Threat Intelligence", active: true },
    ],
  },
  {
    id: "db_toolbox",
    name: "MCP Toolbox (DB)",
    url: "github.com/googleapis/mcp-toolbox",
    status: "connected",
    category: "database",
    icon: "🗄️",
    tools: [
      { name: "query_sqlite", description: "Natural language to SQL", active: true },
      { name: "semantic_search", description: "Vector search across DBs", active: false },
      { name: "nl2sql", description: "NL→SQL for production DBs", active: true },
    ],
  },
  {
    id: "github",
    name: "GitHub MCP",
    url: "github.com/github/github-mcp-server",
    status: "connected",
    category: "comms",
    icon: "🐙",
    tools: [
      { name: "repo_analysis", description: "Code pattern analysis", active: true },
      { name: "issue_manage", description: "Issues & PR automation", active: true },
      { name: "ci_monitor", description: "GitHub Actions intelligence", active: true },
    ],
  },
  {
    id: "workspace",
    name: "Google Workspace MCP",
    url: "uvx workspace-mcp --tool-tier complete",
    status: "disconnected",
    category: "comms",
    icon: "📧",
    tools: [
      { name: "gmail_search", description: "Natural language email search", active: false },
      { name: "calendar_manage", description: "Schedule & event management", active: false },
      { name: "drive_query", description: "Drive file intelligence", active: false },
    ],
  },
];

const INITIAL_N8N_WORKFLOWS: N8NWorkflow[] = [
  {
    id: "wf_001",
    name: "AI Email Labeling",
    category: "email",
    trigger: "New Gmail Message",
    status: "active",
    lastRun: "2 min ago",
    executions: 847,
    description: "Auto-labels incoming Gmail with AI (OpenAI GPT-4o). Routes to correct agent.",
  },
  {
    id: "wf_002",
    name: "Telegram → NEXUS Bridge",
    category: "messaging",
    trigger: "Telegram Message",
    status: "active",
    lastRun: "Just now",
    executions: 3241,
    description: "Routes Telegram commands to Valeria. Supports LangChain memory + voice transcription.",
  },
  {
    id: "wf_003",
    name: "Security Alert Pipeline",
    category: "devops",
    trigger: "AEGIS IDS Event",
    status: "active",
    lastRun: "8 min ago",
    executions: 156,
    description: "Receives IDS alerts → enriches with Google Threat Intel → posts to Slack + creates Asana task.",
  },
  {
    id: "wf_004",
    name: "RAG Knowledge Sync",
    category: "ai",
    trigger: "File Upload / Schedule",
    status: "active",
    lastRun: "1h ago",
    executions: 89,
    description: "Extracts text from PDFs/Docs → chunks → embeds to Qdrant vector DB for NEXUS memory.",
  },
  {
    id: "wf_005",
    name: "Agent Metrics Dashboard",
    category: "devops",
    trigger: "Every 5 minutes",
    status: "active",
    lastRun: "3 min ago",
    executions: 2890,
    description: "Collects agent health scores, task rates, and error logs → pushes to Google Sheets.",
  },
  {
    id: "wf_006",
    name: "WhatsApp Business Bot",
    category: "messaging",
    trigger: "WhatsApp Message",
    status: "paused",
    lastRun: "3h ago",
    executions: 412,
    description: "Business AI chatbot using OpenAI RAG. Handles FAQ, appointments, product queries.",
  },
  {
    id: "wf_007",
    name: "Code Vulnerability Scanner",
    category: "security",
    trigger: "GitHub Push Event",
    status: "active",
    lastRun: "15 min ago",
    executions: 234,
    description: "Triggers on PR/push → runs CodeAgentPRO + AEGIS scan → comments findings on GitHub PR.",
  },
  {
    id: "wf_008",
    name: "Financial Data Aggregator",
    category: "finance",
    trigger: "Every hour",
    status: "active",
    lastRun: "45 min ago",
    executions: 1567,
    description: "Fetches crypto prices, stock data → NMS economy analysis → Telegram daily briefing.",
  },
];

const INITIAL_AGENTS: Agent[] = [
  { id: "valeria", name: "Valeria (Brain)", role: "Cerebro Central", status: "active", attribution_score: 98, tasks_completed: 4521, avg_confidence: 0.94 },
  { id: "aegis", name: "AegisShield PRO", role: "Security PRO", status: "working", attribution_score: 95, tasks_completed: 1203, avg_confidence: 0.91 },
  { id: "code_pro", name: "CodeGuard PRO", role: "Code Engineer", status: "idle", attribution_score: 87, tasks_completed: 342, avg_confidence: 0.88 },
  { id: "deep_search", name: "DeepSearch PRO", role: "Researcher", status: "idle", attribution_score: 82, tasks_completed: 891, avg_confidence: 0.85 },
  { id: "nms_bot", name: "NMS-Bot PRO", role: "Game Agent", status: "idle", attribution_score: 76, tasks_completed: 2134, avg_confidence: 0.79 },
  { id: "architect", name: "NexusArchitect", role: "Architect", status: "working", attribution_score: 91, tasks_completed: 156, avg_confidence: 0.92 },
];

// ─── Attribution Engine Component ─────────────────────────────────────────────

function AttributionPanel({ agents }: { agents: Agent[] }) {
  const [selected, setSelected] = useState<Agent | null>(null);
  const [tracing, setTracing] = useState(false);
  const [trace, setTrace] = useState<AttributionChain[]>([]);

  const runTrace = useCallback(async (agent: Agent) => {
    setSelected(agent);
    setTracing(true);
    setTrace([]);
    const steps: AttributionChain[] = [
      { step: 1, actor: "Router v3.8", action: "Detectó intención", output: `Delegó a ${agent.name}`, confidence: 0.97 },
      { step: 2, actor: agent.name, action: "Procesó tarea", output: "Ejecutó habilidad principal", confidence: agent.avg_confidence },
      { step: 3, actor: "MemoryService", action: "Persistió resultado", output: "Hash SHA-256 generado", confidence: 0.99 },
      { step: 4, actor: "AEGIS Monitor", action: "Validó integridad", output: "Cadena de auditoría OK", confidence: 0.95 },
    ];
    for (const step of steps) {
      await new Promise((r) => setTimeout(r, 400));
      setTrace((prev) => [...prev, step]);
    }
    setTracing(false);
  }, []);

  return (
    <div className="h-full flex flex-col gap-4">
      <div className="grid grid-cols-3 gap-3">
        {agents.map((a) => (
          <button
            key={a.id}
            onClick={() => runTrace(a)}
            className={`p-3 rounded-xl border text-left transition-all ${
              selected?.id === a.id
                ? "border-cyan-400 bg-cyan-400/10"
                : "border-[#2a2a2a] bg-[#141414] hover:border-[#444]"
            }`}
          >
            <div className="flex items-center justify-between mb-1">
              <span className="text-[10px] font-bold text-white truncate">{a.name}</span>
              <span
                className={`w-2 h-2 rounded-full ${
                  a.status === "active" ? "bg-green-400 animate-pulse" :
                  a.status === "working" ? "bg-cyan-400 animate-pulse" : "bg-gray-600"
                }`}
              />
            </div>
            <div className="flex items-center gap-2">
              <div className="flex-1 h-1 bg-gray-800 rounded-full overflow-hidden">
                <div className="h-full bg-cyan-500" style={{ width: `${a.attribution_score}%` }} />
              </div>
              <span className="text-[9px] text-cyan-400 font-mono">{a.attribution_score}%</span>
            </div>
            <div className="text-[9px] text-gray-500 mt-1">{a.role}</div>
          </button>
        ))}
      </div>

      {selected && (
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex-1 bg-[#0d0d0d] border border-[#1e1e1e] rounded-2xl p-4 overflow-y-auto"
        >
          <div className="flex items-center gap-2 mb-4">
            <div className="w-2 h-2 bg-cyan-400 rounded-full animate-pulse" />
            <span className="text-xs font-bold text-white">Trazado Atribucional: {selected.name}</span>
            {tracing && <span className="text-[9px] text-cyan-400 animate-pulse ml-auto">analizando...</span>}
          </div>
          <div className="space-y-3">
            {trace.map((step) => (
              <motion.div
                key={step.step}
                initial={{ opacity: 0, x: -10 }}
                animate={{ opacity: 1, x: 0 }}
                className="flex gap-3"
              >
                <div className="flex flex-col items-center">
                  <div className="w-5 h-5 rounded-full bg-cyan-400/20 border border-cyan-400/40 flex items-center justify-center">
                    <span className="text-[8px] text-cyan-400 font-bold">{step.step}</span>
                  </div>
                  {step.step < trace.length && <div className="w-px flex-1 bg-[#2a2a2a] mt-1" />}
                </div>
                <div className="flex-1 pb-3">
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] font-bold text-cyan-300">{step.actor}</span>
                    <span className="text-[9px] text-gray-500 font-mono">{(step.confidence * 100).toFixed(0)}% conf.</span>
                  </div>
                  <p className="text-[10px] text-gray-400">{step.action}</p>
                  <p className="text-[10px] text-gray-600 italic">{step.output}</p>
                </div>
              </motion.div>
            ))}
          </div>
          {!tracing && trace.length > 0 && (
            <div className="mt-4 p-3 bg-cyan-400/5 border border-cyan-400/20 rounded-xl">
              <p className="text-[10px] text-cyan-400 font-bold">✓ Atribución verificada — Cadena de 4 pasos auditada</p>
              <p className="text-[10px] text-gray-500 mt-1">
                Confianza promedio: {(trace.reduce((a, b) => a + b.confidence, 0) / trace.length * 100).toFixed(1)}% · Ed25519 hash OK
              </p>
            </div>
          )}
        </motion.div>
      )}
    </div>
  );
}

// ─── MCP Panel ─────────────────────────────────────────────────────────────

function MCPPanel({ servers }: { servers: MCPServer[] }) {
  const [selected, setSelected] = useState<MCPServer | null>(null);
  const catColors: Record<string, string> = {
    security: "text-red-400 border-red-400/30 bg-red-400/5",
    database: "text-blue-400 border-blue-400/30 bg-blue-400/5",
    cloud: "text-sky-400 border-sky-400/30 bg-sky-400/5",
    search: "text-yellow-400 border-yellow-400/30 bg-yellow-400/5",
    comms: "text-purple-400 border-purple-400/30 bg-purple-400/5",
  };

  return (
    <div className="h-full flex gap-4">
      <div className="w-52 flex-shrink-0 space-y-2 overflow-y-auto">
        <p className="text-[9px] text-gray-500 uppercase tracking-widest font-bold px-1 mb-3">Servidores MCP</p>
        {servers.map((srv) => (
          <button
            key={srv.id}
            onClick={() => setSelected(srv)}
            className={`w-full p-3 rounded-xl border text-left transition-all ${
              selected?.id === srv.id ? "border-cyan-400 bg-cyan-400/10" : "border-[#2a2a2a] bg-[#141414] hover:border-[#333]"
            }`}
          >
            <div className="flex items-center gap-2">
              <span className="text-base">{srv.icon}</span>
              <div className="flex-1 min-w-0">
                <p className="text-[10px] font-bold text-white truncate">{srv.name}</p>
                <p className={`text-[8px] uppercase font-bold ${catColors[srv.category]?.split(" ")[0]}`}>{srv.category}</p>
              </div>
              <span
                className={`w-1.5 h-1.5 rounded-full flex-shrink-0 ${
                  srv.status === "connected" ? "bg-green-400 animate-pulse" : "bg-red-500"
                }`}
              />
            </div>
          </button>
        ))}
      </div>

      <div className="flex-1 overflow-y-auto">
        {selected ? (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-4">
            <div className="flex items-center gap-3 p-4 bg-[#141414] border border-[#222] rounded-2xl">
              <span className="text-2xl">{selected.icon}</span>
              <div>
                <h3 className="font-bold text-white">{selected.name}</h3>
                <code className="text-[9px] text-gray-500 bg-black/50 px-2 py-0.5 rounded">{selected.url}</code>
              </div>
              <span
                className={`ml-auto px-2 py-1 rounded text-[9px] font-bold uppercase ${
                  selected.status === "connected" ? "bg-green-400/10 text-green-400 border border-green-400/20" : "bg-red-400/10 text-red-400 border border-red-400/20"
                }`}
              >
                {selected.status}
              </span>
            </div>

            <div className="space-y-2">
              <p className="text-[9px] text-gray-500 uppercase tracking-widest font-bold px-1">Herramientas Disponibles</p>
              {selected.tools.map((tool) => (
                <div key={tool.name} className="flex items-center gap-3 p-3 bg-[#141414] border border-[#1e1e1e] rounded-xl">
                  <div
                    className={`w-8 h-4 rounded-full transition-all relative flex-shrink-0 ${
                      tool.active ? "bg-cyan-500" : "bg-gray-700"
                    }`}
                  >
                    <div
                      className={`absolute top-0.5 w-3 h-3 bg-white rounded-full transition-all ${
                        tool.active ? "right-0.5" : "left-0.5"
                      }`}
                    />
                  </div>
                  <div>
                    <p className="text-[10px] font-bold text-white">{tool.name}</p>
                    <p className="text-[9px] text-gray-500">{tool.description}</p>
                  </div>
                  {tool.active && (
                    <span className="ml-auto text-[8px] bg-cyan-400/10 text-cyan-400 border border-cyan-400/20 px-2 py-0.5 rounded uppercase font-bold">
                      activo
                    </span>
                  )}
                </div>
              ))}
            </div>

            <div className="p-4 bg-[#0d0d0d] border border-[#1e1e1e] rounded-2xl">
              <p className="text-[10px] font-bold text-gray-400 mb-2">Integración con NEXUS AEGIS</p>
              <p className="text-[10px] text-gray-600 leading-relaxed">
                Este servidor MCP está registrado en el <span className="text-cyan-400">IntelligentRouter v3.8</span>. Sus herramientas activas son
                accesibles por Valeria y los sub-agentes a través del protocolo MCP. El sistema de atribución registra cada llamada
                con firma Ed25519.
              </p>
            </div>
          </motion.div>
        ) : (
          <div className="h-full flex items-center justify-center text-gray-600 text-sm">
            Selecciona un servidor MCP para ver sus herramientas
          </div>
        )}
      </div>
    </div>
  );
}

// ─── N8N Workflows Panel ───────────────────────────────────────────────────

function N8NPanel({ workflows }: { workflows: N8NWorkflow[] }) {
  const [filter, setFilter] = useState("all");
  const catColors: Record<string, string> = {
    email: "bg-blue-400/10 text-blue-400 border-blue-400/20",
    messaging: "bg-purple-400/10 text-purple-400 border-purple-400/20",
    devops: "bg-orange-400/10 text-orange-400 border-orange-400/20",
    ai: "bg-cyan-400/10 text-cyan-400 border-cyan-400/20",
    security: "bg-red-400/10 text-red-400 border-red-400/20",
    finance: "bg-green-400/10 text-green-400 border-green-400/20",
  };

  const cats = ["all", ...Array.from(new Set(workflows.map((w) => w.category)))];
  const filtered = filter === "all" ? workflows : workflows.filter((w) => w.category === filter);

  return (
    <div className="h-full flex flex-col gap-4">
      <div className="flex gap-2 flex-wrap">
        {cats.map((c) => (
          <button
            key={c}
            onClick={() => setFilter(c)}
            className={`px-3 py-1 rounded-full text-[9px] uppercase tracking-widest font-bold transition-all border ${
              filter === c ? "bg-cyan-400/20 text-cyan-400 border-cyan-400/40" : "border-[#2a2a2a] text-gray-500 hover:text-gray-300"
            }`}
          >
            {c}
          </button>
        ))}
        <span className="ml-auto text-[9px] text-gray-600 self-center">{filtered.length} workflows</span>
      </div>

      <div className="flex-1 overflow-y-auto space-y-2">
        {filtered.map((wf) => (
          <motion.div
            key={wf.id}
            layout
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="p-4 bg-[#141414] border border-[#1e1e1e] rounded-2xl hover:border-[#2a2a2a] transition-all group"
          >
            <div className="flex items-start justify-between mb-2">
              <div className="flex-1">
                <div className="flex items-center gap-2">
                  <span className={`text-[8px] uppercase font-bold px-2 py-0.5 rounded border ${catColors[wf.category]}`}>
                    {wf.category}
                  </span>
                  <span
                    className={`text-[8px] uppercase font-bold px-1.5 py-0.5 rounded ${
                      wf.status === "active" ? "bg-green-400/10 text-green-400" :
                      wf.status === "paused" ? "bg-gray-600/20 text-gray-400" : "bg-red-400/10 text-red-400"
                    }`}
                  >
                    {wf.status}
                  </span>
                </div>
                <h4 className="text-xs font-bold text-white mt-1.5">{wf.name}</h4>
                <p className="text-[10px] text-gray-500 mt-0.5 leading-relaxed">{wf.description}</p>
              </div>
              <div className="text-right flex-shrink-0 ml-4">
                <p className="text-xs font-bold text-white">{wf.executions.toLocaleString()}</p>
                <p className="text-[8px] text-gray-600">ejecuciones</p>
              </div>
            </div>
            <div className="flex items-center gap-3 pt-2 border-t border-[#1a1a1a]">
              <div className="flex items-center gap-1">
                <span className="w-1 h-1 rounded-full bg-cyan-400" />
                <span className="text-[9px] text-gray-500">Trigger: {wf.trigger}</span>
              </div>
              {wf.lastRun && (
                <span className="text-[9px] text-gray-600 ml-auto">Última ejecución: {wf.lastRun}</span>
              )}
            </div>
          </motion.div>
        ))}
      </div>
    </div>
  );
}

// ─── Infinite Canvas ──────────────────────────────────────────────────────────

const WIDGET_TYPES: { type: WidgetType; label: string; icon: string }[] = [
  { type: "system_health", label: "System Health", icon: "💓" },
  { type: "attribution_map", label: "Attribution Map", icon: "🧭" },
  { type: "mcp_status", label: "MCP Status", icon: "🔌" },
  { type: "security_feed", label: "Security Feed", icon: "🛡️" },
  { type: "agent_network", label: "Agent Network", icon: "🤖" },
  { type: "chat", label: "Chat Widget", icon: "💬" },
];

function CanvasWidget({
  widget,
  onMove,
}: {
  widget: Widget;
  onMove: (id: string, dx: number, dy: number) => void;
}) {
  const dragRef = useRef<{ startX: number; startY: number } | null>(null);

  const handleMouseDown = useCallback(
    (e: React.MouseEvent) => {
      e.preventDefault();
      dragRef.current = { startX: e.clientX, startY: e.clientY };
      const handleMove = (e: MouseEvent) => {
        if (!dragRef.current) return;
        const dx = e.clientX - dragRef.current.startX;
        const dy = e.clientY - dragRef.current.startY;
        dragRef.current = { startX: e.clientX, startY: e.clientY };
        onMove(widget.id, dx, dy);
      };
      const handleUp = () => {
        dragRef.current = null;
        window.removeEventListener("mousemove", handleMove);
        window.removeEventListener("mouseup", handleUp);
      };
      window.addEventListener("mousemove", handleMove);
      window.addEventListener("mouseup", handleUp);
    },
    [widget.id, onMove]
  );

  const icons: Record<WidgetType, string> = {
    system_health: "💓",
    attribution_map: "🧭",
    mcp_status: "🔌",
    n8n_workflows: "⚡",
    agent_network: "🤖",
    security_feed: "🛡️",
    chat: "💬",
    memory_graph: "🧠",
    custom: "🔧",
  };

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.9 }}
      animate={{ opacity: 1, scale: 1 }}
      className="absolute bg-[#111] border border-[#222] rounded-2xl overflow-hidden shadow-2xl"
      style={{ left: widget.x, top: widget.y, width: widget.w, height: widget.h }}
    >
      <div
        className="flex items-center gap-2 px-3 py-2 bg-[#0d0d0d] border-b border-[#1a1a1a] cursor-grab active:cursor-grabbing select-none"
        onMouseDown={handleMouseDown}
      >
        <span className="text-sm">{icons[widget.type]}</span>
        <span className="text-[10px] font-bold text-white flex-1 truncate">{widget.title}</span>
        <div className="flex gap-1">
          <div className="w-2 h-2 rounded-full bg-red-500" />
          <div className="w-2 h-2 rounded-full bg-yellow-500" />
          <div className="w-2 h-2 rounded-full bg-green-500" />
        </div>
      </div>
      <div className="p-3 h-[calc(100%-36px)] overflow-auto">
        <WidgetContent type={widget.type} />
      </div>
    </motion.div>
  );
}

function WidgetContent({ type }: { type: WidgetType }) {
  const [tick, setTick] = useState(0);
  useEffect(() => {
    const id = setInterval(() => setTick((t) => t + 1), 2000);
    return () => clearInterval(id);
  }, []);

  if (type === "system_health") {
    const cpu = 20 + Math.sin(tick * 0.5) * 15 + Math.random() * 5;
    const ram = 45 + Math.sin(tick * 0.3) * 8;
    const metrics = [
      { label: "CPU", value: cpu, color: "#22d3ee" },
      { label: "RAM", value: ram, color: "#a78bfa" },
      { label: "Agentes", value: 73, color: "#34d399" },
      { label: "Safe Mode", value: 100, color: "#f59e0b" },
    ];
    return (
      <div className="space-y-2">
        {metrics.map((m) => (
          <div key={m.label}>
            <div className="flex justify-between text-[9px] mb-1">
              <span className="text-gray-400">{m.label}</span>
              <span style={{ color: m.color }}>{m.value.toFixed(1)}%</span>
            </div>
            <div className="h-1 bg-[#1a1a1a] rounded-full overflow-hidden">
              <motion.div
                className="h-full rounded-full"
                style={{ backgroundColor: m.color }}
                animate={{ width: `${m.value}%` }}
                transition={{ duration: 0.5 }}
              />
            </div>
          </div>
        ))}
      </div>
    );
  }

  if (type === "attribution_map") {
    const nodes = [
      { x: 50, y: 20, label: "Valeria", color: "#a78bfa" },
      { x: 20, y: 65, label: "AEGIS", color: "#f87171" },
      { x: 80, y: 65, label: "Router", color: "#22d3ee" },
      { x: 50, y: 90, label: "Memory", color: "#34d399" },
    ];
    return (
      <svg viewBox="0 0 100 100" className="w-full h-full">
        {[
          [0, 1], [0, 2], [0, 3], [1, 3], [2, 3],
        ].map(([a, b], i) => (
          <line
            key={i}
            x1={nodes[a].x}
            y1={nodes[a].y}
            x2={nodes[b].x}
            y2={nodes[b].y}
            stroke="#2a2a2a"
            strokeWidth="0.5"
          />
        ))}
        {nodes.map((n, i) => (
          <g key={i}>
            <circle cx={n.x} cy={n.y} r="6" fill={n.color + "20"} stroke={n.color} strokeWidth="0.5" />
            <text x={n.x} y={n.y + 1} textAnchor="middle" dominantBaseline="middle" fontSize="2.5" fill={n.color}>
              {n.label.charAt(0)}
            </text>
            <text x={n.x} y={n.y + 10} textAnchor="middle" fontSize="2" fill="#666">
              {n.label}
            </text>
          </g>
        ))}
      </svg>
    );
  }

  if (type === "security_feed") {
    const events = [
      { time: "00:01", msg: "AEGIS: Port scan bloqueado", sev: "high" },
      { time: "00:03", msg: "Safe Mode activado automáticamente", sev: "medium" },
      { time: "00:05", msg: "Chronicle: Amenaza analizada", sev: "low" },
      { time: "00:07", msg: "IDS: 3 IPs en blacklist", sev: "high" },
    ];
    return (
      <div className="space-y-1.5">
        {events.map((e, i) => (
          <div key={i} className="flex items-start gap-2">
            <span className="text-[8px] text-gray-600 font-mono flex-shrink-0">{e.time}</span>
            <span
              className={`text-[8px] leading-tight ${
                e.sev === "high" ? "text-red-400" : e.sev === "medium" ? "text-yellow-400" : "text-gray-400"
              }`}
            >
              {e.msg}
            </span>
          </div>
        ))}
      </div>
    );
  }

  if (type === "mcp_status") {
    const connected = INITIAL_MCP_SERVERS.filter((s) => s.status === "connected").length;
    return (
      <div className="space-y-2">
        <div className="text-center">
          <span className="text-3xl font-bold text-cyan-400">{connected}</span>
          <span className="text-[9px] text-gray-500 block">/ {INITIAL_MCP_SERVERS.length} servidores</span>
        </div>
        {INITIAL_MCP_SERVERS.map((s) => (
          <div key={s.id} className="flex items-center gap-2">
            <span className="text-xs">{s.icon}</span>
            <span className="text-[9px] text-gray-400 flex-1 truncate">{s.name}</span>
            <span className={`w-1.5 h-1.5 rounded-full ${s.status === "connected" ? "bg-green-400" : "bg-red-500"}`} />
          </div>
        ))}
      </div>
    );
  }

  if (type === "agent_network") {
    return (
      <div className="space-y-1.5">
        {INITIAL_AGENTS.map((a) => (
          <div key={a.id} className="flex items-center gap-2">
            <span
              className={`w-1.5 h-1.5 rounded-full flex-shrink-0 ${
                a.status === "active" ? "bg-green-400 animate-pulse" :
                a.status === "working" ? "bg-cyan-400 animate-pulse" : "bg-gray-600"
              }`}
            />
            <span className="text-[9px] text-gray-400 flex-1 truncate">{a.name}</span>
            <span className="text-[8px] text-cyan-400 font-mono">{a.attribution_score}%</span>
          </div>
        ))}
      </div>
    );
  }

  return (
    <div className="flex items-center justify-center h-full text-gray-600 text-xs">
      Widget cargando...
    </div>
  );
}

function InfiniteCanvas() {
  const [widgets, setWidgets] = useState<Widget[]>([
    { id: "w1", type: "system_health", title: "System Health", x: 40, y: 40, w: 240, h: 180, status: "active" },
    { id: "w2", type: "attribution_map", title: "Attribution Map", x: 300, y: 40, w: 220, h: 200, status: "active" },
    { id: "w3", type: "security_feed", title: "Security Feed (AEGIS)", x: 40, y: 240, w: 480, h: 180, status: "active" },
    { id: "w4", type: "mcp_status", title: "MCP Servers", x: 540, y: 40, w: 200, h: 220, status: "active" },
    { id: "w5", type: "agent_network", title: "Agent Network", x: 540, y: 280, w: 200, h: 180, status: "active" },
  ]);
  const [pan, setPan] = useState({ x: 0, y: 0 });
  const [zoom, setZoom] = useState(1);
  const [adding, setAdding] = useState(false);
  const canvasRef = useRef<HTMLDivElement>(null);

  const moveWidget = useCallback((id: string, dx: number, dy: number) => {
    setWidgets((prev) => prev.map((w) => (w.id === id ? { ...w, x: w.x + dx / zoom, y: w.y + dy / zoom } : w)));
  }, [zoom]);

  const addWidget = useCallback((type: WidgetType, label: string) => {
    const newWidget: Widget = {
      id: `w${Date.now()}`,
      type,
      title: label,
      x: 100 - pan.x / zoom,
      y: 100 - pan.y / zoom,
      w: 240,
      h: 200,
      status: "active",
    };
    setWidgets((prev) => [...prev, newWidget]);
    setAdding(false);
  }, [pan, zoom]);

  useEffect(() => {
    const handleWheel = (e: WheelEvent) => {
      e.preventDefault();
      if (e.ctrlKey) {
        setZoom((z) => Math.max(0.3, Math.min(2, z - e.deltaY * 0.001)));
      } else {
        setPan((p) => ({ x: p.x - e.deltaX, y: p.y - e.deltaY }));
      }
    };
    const el = canvasRef.current;
    el?.addEventListener("wheel", handleWheel, { passive: false });
    return () => el?.removeEventListener("wheel", handleWheel);
  }, []);

  return (
    <div className="relative h-full bg-[#080808] overflow-hidden" ref={canvasRef}>
      {/* Grid Background */}
      <div
        className="absolute inset-0 opacity-20"
        style={{
          backgroundImage: `radial-gradient(circle, #333 1px, transparent 1px)`,
          backgroundSize: `${20 * zoom}px ${20 * zoom}px`,
          backgroundPosition: `${pan.x % (20 * zoom)}px ${pan.y % (20 * zoom)}px`,
        }}
      />

      {/* Canvas Controls */}
      <div className="absolute top-3 right-3 z-20 flex items-center gap-2">
        <span className="text-[9px] text-gray-600 font-mono">{(zoom * 100).toFixed(0)}%</span>
        <button onClick={() => setZoom((z) => Math.min(2, z + 0.1))} className="w-7 h-7 bg-[#141414] border border-[#222] rounded-lg text-gray-400 hover:text-white text-xs">+</button>
        <button onClick={() => setZoom((z) => Math.max(0.3, z - 0.1))} className="w-7 h-7 bg-[#141414] border border-[#222] rounded-lg text-gray-400 hover:text-white text-xs">−</button>
        <button onClick={() => { setZoom(1); setPan({ x: 0, y: 0 }); }} className="px-2 h-7 bg-[#141414] border border-[#222] rounded-lg text-[9px] text-gray-400 hover:text-white">Reset</button>
        <button onClick={() => setAdding(true)} className="px-3 h-7 bg-cyan-600 hover:bg-cyan-500 rounded-lg text-[9px] font-bold text-white transition-all">+ Widget</button>
      </div>

      {/* Widgets */}
      <div
        className="absolute"
        style={{ transform: `translate(${pan.x}px, ${pan.y}px) scale(${zoom})`, transformOrigin: "0 0" }}
      >
        {widgets.map((w) => (
          <CanvasWidget key={w.id} widget={w} onMove={moveWidget} />
        ))}
      </div>

      {/* Add Widget Modal */}
      <AnimatePresence>
        {adding && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="absolute inset-0 bg-black/60 flex items-center justify-center z-30"
            onClick={() => setAdding(false)}
          >
            <motion.div
              initial={{ scale: 0.9 }}
              animate={{ scale: 1 }}
              exit={{ scale: 0.9 }}
              className="bg-[#111] border border-[#222] rounded-2xl p-6 w-80"
              onClick={(e) => e.stopPropagation()}
            >
              <h3 className="text-sm font-bold text-white mb-4">Agregar Widget al Canvas</h3>
              <div className="grid grid-cols-2 gap-2">
                {WIDGET_TYPES.map((wt) => (
                  <button
                    key={wt.type}
                    onClick={() => addWidget(wt.type, wt.label)}
                    className="p-3 bg-[#1a1a1a] border border-[#2a2a2a] hover:border-cyan-400/50 rounded-xl text-left transition-all"
                  >
                    <span className="text-lg block mb-1">{wt.icon}</span>
                    <span className="text-[10px] font-bold text-white">{wt.label}</span>
                  </button>
                ))}
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

// ─── Main App ─────────────────────────────────────────────────────────────────

export default function App() {
  const [activePanel, setActivePanel] = useState<ActivePanel>("canvas");
  const [mcpServers] = useState<MCPServer[]>(INITIAL_MCP_SERVERS);
  const [workflows] = useState<N8NWorkflow[]>(INITIAL_N8N_WORKFLOWS);
  const [agents] = useState<Agent[]>(INITIAL_AGENTS);
  const [globalStatus] = useState({ connected: true, safeMode: true, lockdown: false });

  const nav: { id: ActivePanel; label: string; icon: string; badge?: number }[] = [
    { id: "canvas", label: "Canvas Infinito", icon: "⬡" },
    { id: "attribution", label: "Atribución IA", icon: "🧭", badge: agents.filter(a => a.status === "working").length },
    { id: "mcp", label: "Servidores MCP", icon: "🔌", badge: mcpServers.filter(s => s.status === "connected").length },
    { id: "n8n", label: "Automatización n8n", icon: "⚡", badge: workflows.filter(w => w.status === "active").length },
    { id: "agents", label: "Red de Agentes", icon: "🤖" },
  ];

  return (
    <div className="min-h-screen bg-[#080808] text-gray-100 flex flex-col font-mono">
      {/* Header */}
      <header className="flex-shrink-0 border-b border-[#111] bg-[#080808]/90 backdrop-blur px-5 py-3 flex items-center gap-4">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-lg bg-cyan-500/10 border border-cyan-500/30 flex items-center justify-center">
            <span className="text-cyan-400 text-sm">⬡</span>
          </div>
          <div>
            <h1 className="text-sm font-bold text-white tracking-tight">
              NEXUS AEGIS <span className="text-cyan-400">v5.0</span>
            </h1>
            <p className="text-[8px] text-gray-600 uppercase tracking-widest">Sistema de Inteligencia Atribucional</p>
          </div>
        </div>

        {/* System Status Pills */}
        <div className="flex items-center gap-2 ml-4">
          <span className="flex items-center gap-1.5 px-2 py-1 bg-green-400/5 border border-green-400/20 rounded-full">
            <span className="w-1.5 h-1.5 bg-green-400 rounded-full animate-pulse" />
            <span className="text-[8px] text-green-400 font-bold uppercase">Online</span>
          </span>
          <span className="flex items-center gap-1.5 px-2 py-1 bg-cyan-400/5 border border-cyan-400/20 rounded-full">
            <span className="w-1.5 h-1.5 bg-cyan-400 rounded-full" />
            <span className="text-[8px] text-cyan-400 font-bold uppercase">Safe Mode</span>
          </span>
          <span className="flex items-center gap-1.5 px-2 py-1 bg-[#141414] border border-[#1e1e1e] rounded-full">
            <span className="w-1.5 h-1.5 bg-purple-400 rounded-full" />
            <span className="text-[8px] text-gray-400 uppercase">
              {mcpServers.filter(s => s.status === "connected").length} MCP
            </span>
          </span>
          <span className="flex items-center gap-1.5 px-2 py-1 bg-[#141414] border border-[#1e1e1e] rounded-full">
            <span className="w-1.5 h-1.5 bg-orange-400 rounded-full animate-pulse" />
            <span className="text-[8px] text-gray-400 uppercase">
              {workflows.filter(w => w.status === "active").length} n8n Active
            </span>
          </span>
        </div>

        <div className="ml-auto flex items-center gap-2">
          <span className="text-[8px] text-gray-600">Valeria · Cerebro Central · Nemotron/Gemma4</span>
        </div>
      </header>

      {/* Body */}
      <div className="flex flex-1 overflow-hidden">
        {/* Sidebar */}
        <nav className="w-48 flex-shrink-0 border-r border-[#111] bg-[#060606] p-3 flex flex-col gap-1">
          {nav.map((item) => (
            <button
              key={item.id}
              onClick={() => setActivePanel(item.id)}
              className={`flex items-center gap-2.5 px-3 py-2.5 rounded-xl text-left transition-all ${
                activePanel === item.id
                  ? "bg-cyan-400/10 border border-cyan-400/30 text-cyan-400"
                  : "text-gray-500 hover:text-gray-300 hover:bg-[#111]"
              }`}
            >
              <span className="text-base">{item.icon}</span>
              <span className="text-[10px] font-bold flex-1">{item.label}</span>
              {item.badge !== undefined && (
                <span className={`text-[8px] font-bold px-1.5 py-0.5 rounded-full ${
                  activePanel === item.id ? "bg-cyan-400/20 text-cyan-400" : "bg-[#1a1a1a] text-gray-500"
                }`}>
                  {item.badge}
                </span>
              )}
            </button>
          ))}

          {/* Attribution Score Summary */}
          <div className="mt-auto p-3 bg-[#0d0d0d] border border-[#1a1a1a] rounded-xl">
            <p className="text-[8px] text-gray-600 uppercase font-bold mb-2">Confianza Global</p>
            <div className="text-center">
              <span className="text-2xl font-bold text-cyan-400">
                {(agents.reduce((a, b) => a + b.avg_confidence, 0) / agents.length * 100).toFixed(0)}%
              </span>
              <p className="text-[8px] text-gray-600">promedio atribucional</p>
            </div>
            <div className="mt-2 h-1 bg-[#1a1a1a] rounded-full overflow-hidden">
              <div className="h-full bg-gradient-to-r from-cyan-500 to-purple-500 w-[89%]" />
            </div>
          </div>
        </nav>

        {/* Main Content */}
        <main className="flex-1 overflow-hidden p-4">
          <AnimatePresence mode="wait">
            <motion.div
              key={activePanel}
              initial={{ opacity: 0, y: 4 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -4 }}
              transition={{ duration: 0.15 }}
              className="h-full"
            >
              {activePanel === "canvas" && <InfiniteCanvas />}
              {activePanel === "attribution" && (
                <div className="h-full flex flex-col gap-3">
                  <div className="flex items-center gap-2">
                    <span className="text-base">🧭</span>
                    <h2 className="text-sm font-bold text-white">Motor de Inteligencia Atribucional</h2>
                    <span className="text-[9px] text-gray-500 bg-[#141414] border border-[#222] px-2 py-0.5 rounded-full ml-2">
                      Ed25519 · SHA-256 · RBAC
                    </span>
                  </div>
                  <p className="text-[10px] text-gray-500 leading-relaxed">
                    Cada acción de agente es trazada criptográficamente. Selecciona un agente para ver su cadena de atribución completa — desde la detección de intención hasta la persistencia en memoria.
                  </p>
                  <div className="flex-1 overflow-hidden">
                    <AttributionPanel agents={agents} />
                  </div>
                </div>
              )}
              {activePanel === "mcp" && (
                <div className="h-full flex flex-col gap-3">
                  <div className="flex items-center gap-2">
                    <span className="text-base">🔌</span>
                    <h2 className="text-sm font-bold text-white">Capa de Servidores MCP</h2>
                    <span className="text-[9px] text-gray-500 bg-[#141414] border border-[#222] px-2 py-0.5 rounded-full ml-2">
                      google/mcp · github/mcp · googleapis/gcloud-mcp
                    </span>
                  </div>
                  <p className="text-[10px] text-gray-500">
                    Integración con los servidores MCP oficiales de Google: Security (SecOps/Chronicle/GTI/SCC), Cloud (gcloud CLI), DB Toolbox y GitHub. Cada tool se atribuye a las decisiones de Valeria en el log de auditoría.
                  </p>
                  <div className="flex-1 overflow-hidden">
                    <MCPPanel servers={mcpServers} />
                  </div>
                </div>
              )}
              {activePanel === "n8n" && (
                <div className="h-full flex flex-col gap-3">
                  <div className="flex items-center gap-2">
                    <span className="text-base">⚡</span>
                    <h2 className="text-sm font-bold text-white">Motor de Automatización n8n</h2>
                    <span className="text-[9px] text-gray-500 bg-[#141414] border border-[#222] px-2 py-0.5 rounded-full ml-2">
                      awesome-n8n-templates · 280+ workflows
                    </span>
                  </div>
                  <p className="text-[10px] text-gray-500">
                    Workflows derivados de <code className="text-cyan-400 bg-black/30 px-1 rounded">enescingoz/awesome-n8n-templates</code>. Cada workflow está conectado al Router de NEXUS y sus ejecuciones aparecen en el log atribucional.
                  </p>
                  <div className="flex-1 overflow-hidden">
                    <N8NPanel workflows={workflows} />
                  </div>
                </div>
              )}
              {activePanel === "agents" && (
                <div className="h-full flex flex-col gap-3 overflow-y-auto">
                  <div className="flex items-center gap-2">
                    <span className="text-base">🤖</span>
                    <h2 className="text-sm font-bold text-white">Red de Agentes NEXUS</h2>
                  </div>
                  <div className="grid grid-cols-3 gap-3">
                    {agents.map((a) => (
                      <div key={a.id} className="p-4 bg-[#111] border border-[#1e1e1e] rounded-2xl hover:border-[#2a2a2a] transition-all">
                        <div className="flex items-center justify-between mb-3">
                          <span className="text-xs font-bold text-white truncate">{a.name}</span>
                          <span
                            className={`px-2 py-0.5 rounded text-[8px] font-bold uppercase ${
                              a.status === "active" ? "bg-green-400/10 text-green-400" :
                              a.status === "working" ? "bg-cyan-400/10 text-cyan-400" : "bg-gray-600/10 text-gray-500"
                            }`}
                          >
                            {a.status}
                          </span>
                        </div>
                        <p className="text-[9px] text-gray-500 mb-3">{a.role}</p>
                        <div className="space-y-2">
                          <div>
                            <div className="flex justify-between text-[8px] mb-1">
                              <span className="text-gray-600">Attribution Score</span>
                              <span className="text-cyan-400">{a.attribution_score}%</span>
                            </div>
                            <div className="h-1 bg-[#1a1a1a] rounded-full overflow-hidden">
                              <div className="h-full bg-cyan-500" style={{ width: `${a.attribution_score}%` }} />
                            </div>
                          </div>
                          <div>
                            <div className="flex justify-between text-[8px] mb-1">
                              <span className="text-gray-600">Confianza Promedio</span>
                              <span className="text-purple-400">{(a.avg_confidence * 100).toFixed(0)}%</span>
                            </div>
                            <div className="h-1 bg-[#1a1a1a] rounded-full overflow-hidden">
                              <div className="h-full bg-purple-500" style={{ width: `${a.avg_confidence * 100}%` }} />
                            </div>
                          </div>
                        </div>
                        <div className="mt-3 pt-3 border-t border-[#1a1a1a] flex justify-between items-center">
                          <span className="text-[8px] text-gray-600">Tareas completadas</span>
                          <span className="text-[10px] font-bold text-white">{a.tasks_completed.toLocaleString()}</span>
                        </div>
                      </div>
                    ))}
                  </div>
                  <div className="p-4 bg-[#0d0d0d] border border-[#1a1a1a] rounded-2xl">
                    <p className="text-[10px] font-bold text-gray-400 mb-2">
                      Arquitectura de Inteligencia Atribucional
                    </p>
                    <p className="text-[10px] text-gray-600 leading-relaxed">
                      Cada agente registra sus acciones en la cadena de bloques de memoria con hash SHA-256 encadenado.
                      El IntelligentRouter v3.8 asigna un <strong className="text-cyan-400">Attribution Score</strong> basado en
                      tasa de éxito, latencia, coherencia de respuesta y alineación con los objetivos estratégicos.
                      Los Servidores MCP extienden las capacidades de cada agente con herramientas verificadas externamente.
                      Los workflows n8n actúan como capas de automatización asíncronas que reportan al motor atribucional.
                    </p>
                  </div>
                </div>
              )}
            </motion.div>
          </AnimatePresence>
        </main>
      </div>
    </div>
  );
}
